// Employee class and Address struct specification file
// SAM JACKSON

#ifndef EMPLOYEE_H_
#define EMPLOYEE_H_

#include <string>

struct Address
{
	string houseNumber;
	string street;
	string city; 
	string state;
	string zipCode;
};

class Employee
{
	private:
		string firstName {""};
		string lastName {""};
		string homeAddress {""};
		string email {""};
		int employeeID {0};
		int yearsWorked {0};
	public:
		bool setFirstName(string);
		bool setLastName(string);
		bool setHomeAddress(Address);
		bool setEmail(string);
		bool setEmployeeID(int);
		bool setYearsWorked(int);

		string getFirstName();
		string getLastName();
		string getHomeAddress();
		string getEmail();
		int getEmployeeID();
		int getYearsWorked();
};	

#endif 		// EMPLOYEE_H_