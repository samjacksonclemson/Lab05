//NICK BUNGE

#include "Invoice.h"
#include <iostream>
#include <math.h>

using namespace std;


void Invoice::calcStudent(Student stud) //NICK BUNGE
{
    infoReceipt += "Name: " + stud.getFirstName() + " " + stud.getLastName() + "\n";
    infoReceipt += "Email: " + stud.getEmail() + "\n";
    infoReceipt += "Address: " + stud.showHomeAddress() + "\n";
    infoReceipt += "Grade level: " + stud.getGradeLevel() + "\n";
    
    if (stud.getLivingOnCampus())
    {
        infoReceipt += "Housing status: Living on campus\n";
    } else
    {
        infoReceipt += "Housing status: Living off campus\n";
    }

    int intGpa = stud.getGPA() * 10;
//Formats the double GPA into a string for the receipt with one decimal place
    if (intGpa % 10 == 0)
    {
        infoReceipt += "GPA: " + to_string((intGpa - (intGpa % 10))/10) + ".0\n";
    } else 
    {
        infoReceipt += "GPA: " + to_string((intGpa - (intGpa % 10))/10) + "." + to_string(intGpa % 10) + "\n";
    }

    infoReceipt += "CuID: " + stud.getCuID() + "\n\n";

    invoiceStud = stud;
    classesUsed[0] = true;
}

void Invoice::calcMotorcycle(Motorcycle motor, int permitType, int days)  //NICK BUNGE
{
    infoReceipt += "Make: " + motor.getMake() + "\n";
    infoReceipt += "Model: " + motor.getModel() + "\n";
    infoReceipt += "Year: " + to_string(motor.getYear()) + "\n";
    infoReceipt += "License Plate: " + motor.getLicensePlate() + "\n";
    infoReceipt += "Color: " + motor.getColor() + "\n";
    
    if (motor.getHasThreeWheels())
    {
        infoReceipt += "Type: Trike (3 wheels)\n";
    } else
    { infoReceipt += "Type: Motorcycle (2 wheels)\n";}
    
    invoiceMotor = motor;
    permit = permitType + 1; //to accounbt for that motorcylces dont have annual permit
    if (permitType == 2)
    {numDays = days;}
    classesUsed[6] = true;
}

void Invoice::calcEmployee(Employee e) // SAM JACKSON formats string for Employee information
{

	infoReceipt += "Name: " + e.getFirstName() + " " + e.getLastName() + "\n";
    infoReceipt += "Email: " + e.getEmail() + "\n";
    infoReceipt += "Address: " + e.getHomeAddress() + "\n";
    infoReceipt += "Employee ID: " + to_string(e.getEmployeeID()) + "\n";

	// test for long-term discount
	if (e.getYearsWorked() >= 5)
	{
		infoReceipt += "Qualify for Long-Term Employee Discount: Yes\n";
	}
		
	else
	{
		infoReceipt += "Qualify for Long-Term Employee Discount: No\n";
	}

	// copy object e into invoiceEmp
	invoiceEmployee = e;

	// indicate Employee class is used
	classesUsed[1] = true;
    infoReceipt += "\n";
}

void Invoice::calcCar(Car c, int permitType, int days) // SAM JACKSON formats string for Car information
{
	infoReceipt += "Make: " + c.getMake() + "\n";
    infoReceipt += "Model: " + c.getModel() + "\n";
    infoReceipt += "Year: " + to_string(c.getYear()) + "\n";
    infoReceipt += "License Plate: " + c.getLicensePlate() + "\n";
    infoReceipt += "Color: " + c.getColor() + "\n";

	if (c.getIsCompact())
	{
		infoReceipt += "Compact: Yes\n";
	}
	else 
	{
		infoReceipt += "Compact: No\n";
	}

    permit = permitType;
    numDays = days;
	// copy object c into invoiceCar
	invoiceCar = c;

	// indicate Car class is used
	classesUsed[4] = true;
}

void Invoice::calcVisitor(Visitor v) //JONATHAN BREEN
{

	infoReceipt += "Name: " + v.getName() + "\n";
    infoReceipt += "Email: " + v.getEmail() + "\n";
    infoReceipt += "Address: " + v.getAddress() + "\n";
    infoReceipt += "Length of stay: " + to_string(v.getStayLength()) + "\n";
    if (v.getAlumni() == 1)
    {
        infoReceipt += "Alumni: Yes\n";
    }
    else
    {
        infoReceipt += "Alumni: No\n";
    }

	// copy object v into invoiceVisitor
	invoiceVisitor = v;

	// indicate Visitor class is used
	classesUsed[2] = true;
}

void Invoice::calcMoped(Moped m, int permitType, int days) //JONATHAN BREEN
{
	infoReceipt += "Make: " +m.getMake() + "\n";
    infoReceipt += "Model: " + m.getModel() + "\n";
    infoReceipt += "Year: " + to_string(m.getYear()) + "\n";
    infoReceipt += "License Plate: " + m.getLicensePlate() + "\n";
    infoReceipt += "Color: " + m.getColor() + "\n";
    infoReceipt += "Passengers: " + to_string(m.getPassengers()) + "\n";
	

	// copy object m into invoiceMoped
	invoiceMoped = m;

    // Set permitType and Days
    permit = permitType + 1;
    numDays = days;

	// indicate Moped class is used
	classesUsed[7] = true;
}

void Invoice::calcVendor(Vendor v) //RILEY WESTERMAN
{

	infoReceipt += "Name: " + v.getFirstName() +  " " + v.getLastName() + "\n";
    infoReceipt += "Email: " + v.getEmail() + "\n";
    infoReceipt += "Address: " + v.getAddress() + "\n";
    infoReceipt += "Vendor type: " + v.getVendorType() + "\n";
   
    if (v.getAlumni())
    {
        infoReceipt += "Are you an alumni?  Yes\n";
    }
    else
    {
        infoReceipt += "Are you an alumni?  No\n";
    }

	// copy object v into invoiceVisitor
	invoiceVendor = v;

	// indicate Visitor class is used
	classesUsed[3] = true;
}

void Invoice::calcLowE(Low e, int permitType, int days) //RILEY WESTERMAN
{
    infoReceipt += "Make: " +e.getMake() + "\n";
    infoReceipt += "Model: " + e.getModel() + "\n";
    infoReceipt += "Year: " + to_string(e.getYearMade()) + "\n";
    infoReceipt += "License Plate: " + e.getLicensePlate() + "\n";
    infoReceipt += "Emission Type: " + e.getEmissionType() + "\n";
	

	invoiceLow = e;
    // Set permitType and Days
    permit = permitType;
    numDays = days;

	// indicate Moped class is used
	classesUsed[5] = true;
}




string Invoice::printPermitCost() //NICK BUNGE, Prints the money charge for the permit prices including discounts
{

int intCharge;


switch (permit) //Sets base price based on permit
{
case 1:
    totalCharge = 120.00; 
    chargeReceipt += "\nPrice of Annual Permit: $120.00\n";
    break;
case 2:
    totalCharge = 70.00;
    chargeReceipt += "\nPrice of Semester Permit: $70.00\n";
    break;
case 3:
    totalCharge = 7.00 * numDays;
    intCharge = totalCharge * 100;
   //Formats the double intCharge into a string for the receipt with two decimal places
    if (intCharge % 100 == 0)
        {
            chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
            if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
break;
}
       
        intCharge = totalCharge * 0.05 * 100;
        totalCharge = totalCharge + (totalCharge * .05);
         //Formats the double intCharge into a string for the receipt with two decimal places
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Processing fee: +$" + to_string(((intCharge - (intCharge % 100))/100)) + ".00\n";
        } else
        {
            if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Processing fee: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Processing fee: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }

if (classesUsed[0]) //Student
{ 
    if (invoiceStud.getGPA() >= 3.0)    // 10% discount if student has high gpa
    {

        
         intCharge = totalCharge * 0.1 * 100;
          totalCharge = totalCharge - (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
        
    
    }
} else if (classesUsed[1]) //Employee
{
    if (invoiceEmployee.getYearsWorked() >= 5)  //10% discount if employee worked 5+ years
    {
         intCharge = totalCharge * 0.1 * 100;
          totalCharge = totalCharge - (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
    }
} else if (classesUsed[2]) //Visitor
{   if (invoiceVisitor.getAlumni()) //10% discount for alumni
        {
         intCharge = totalCharge * 0.1 * 100;
        totalCharge = totalCharge - (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Alumni discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Alumni discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Alumni discount: -$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
        }

} else if (classesUsed[3]) //Vendor
{
        //20% charge for Vendor
         intCharge = totalCharge * 0.2 * 100;
        totalCharge = totalCharge + (totalCharge * 0.2);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Vendor charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Vendor charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Vendor charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
}


if (classesUsed[4]) //Car 
{
if (!invoiceCar.getIsCompact()) //10% charge if not compact
    {
        intCharge = totalCharge * 0.1 * 100;
        totalCharge = totalCharge + (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
    }
} else if (classesUsed[5]) //Low Emission Vehicle
 {
      if (invoiceLow.getModel() == "Tesla" || invoiceLow.getModel() == "tesla") //10% charge if tesla
    {   

        intCharge = totalCharge * .25 * 100;
        totalCharge = totalCharge + (totalCharge * .25);
         if (intCharge % 100 == 0)
        {
            chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
           if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
            
        }
        
    }
} else if (classesUsed[6]) //Motorcylce
{
    if (invoiceMotor.getHasThreeWheels()) //25% charge if it is a trike
    {   
        intCharge = totalCharge * .25 * 100;
        totalCharge = totalCharge + (totalCharge * .25);
         if (intCharge % 100 == 0)
        {
            chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
           if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
            
        }
        
    }
} else if (classesUsed[7]) //Moped
{
     if (invoiceMoped.getPassengers() >= 3) //15% charge for mopeds with 3 passengers
    {   

        intCharge = totalCharge * .15 * 100;
        totalCharge = totalCharge + (totalCharge * .15);
         if (intCharge % 100 == 0)
        {
            chargeReceipt += "Moped charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
           if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Moped charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Moped charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
            
        }
        
    }
}
   
    return chargeReceipt;
}

double Invoice::getTotalCharge()
{
    return totalCharge;
}

string Invoice::printInvoice()
{
    return infoReceipt;
}