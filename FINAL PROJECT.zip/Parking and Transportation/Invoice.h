//NICK BUNGE
#ifndef INVOICE_H_
#define INVOICE_H_


#include "Student.h"
#include "Motorcycle.h"
#include "Car.h"
#include "Employee.h"
#include "Visitor.h"
#include "Moped.h"
#include "Vendor.h"
#include "LowE.h"


class Invoice 
{
private:
    bool classesUsed[8] {false, false, false, false, false,false,false,false};
    /* 
    Index
    0       Student
    1       Employee
    2       Visitor
    3       Vendor
    4       Car
    5       Low Emission Vehicle
    6       Motorcycle
    7       Moped
    */
   int permit;
   /*  
    1 = Annual Permit
    2 = Semester 
    3 = Daily
   */
    int numDays;
    double totalCharge {0.00};
    string  infoReceipt {""};
    string chargeReceipt {""};
    Student invoiceStud;
    Motorcycle invoiceMotor;
    Car invoiceCar;
    Employee invoiceEmployee;
    Visitor invoiceVisitor;
    Moped invoiceMoped;
    Vendor invoiceVendor;
    Low invoiceLow;

public:
    Invoice() = default;
   
    //NICK BUNGE
    void calcStudent(Student);
    void calcMotorcycle( Motorcycle, int, int);

    //SAM JACKSON
    void calcEmployee(Employee);
    void calcCar(Car, int, int);
   
    //JONATHAN BREEN
    void calcVisitor(Visitor);
    void calcMoped(Moped, int, int);

    //RILEY WESTERMAN
    void calcVendor(Vendor);
    void calcLowE(Low, int, int);

    //NICK BUNGE
    string printInvoice();
    string printPermitCost();
    double getTotalCharge();
};

#endif