// Riley Westerman

#ifndef LOW_E_H_
#define LOW_E_H_
#include <string>
using namespace std;

class Low
{
  private: // Variables
    string make {""};
    string model {""};
    int yearMade {0};
    string emissionType {""};
    string licensePlate {""};

  public:
    Low() = default; // Constructor
    Low(string m, string mo, int y, string e, string l) : make {m}, model {mo}, yearMade {y}, emissionType {e}, licensePlate {l} {}

    void setMake(string make);
    void setModel(string model);
    bool setYearMade(int yearMade);
    bool setEmissionType(string emissionType);
    void setLicensePlate(string licensePlate);

    string getMake();
    string getModel();
    int getYearMade();
    string getEmissionType();
    string getLicensePlate();
};

#endif