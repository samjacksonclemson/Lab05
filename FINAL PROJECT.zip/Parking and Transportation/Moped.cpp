// Moped class set function definitions

#include <string>
#include "Moped.h"

using namespace std;

void Moped::setMake(string mk)
{
    make = mk;
}

void Moped::setModel(string ml)
{
    model = ml;
}

void Moped::setLicensePlate(string l)
{
    licensePlate = l;
}
        
void Moped::setColor(string c)
{
    color = c;
}

bool Moped::setYear(int y)
{
    if (y <= 0)
    {return false;}
    else if (y > 2022)
    {return false;}
    else
    {
        year = y;
        return true;
    }
}

bool Moped::setPassengers(int p)
{
    if (p < 0)
    {return false;}
    else if (p > 2)
    {return false;}
    else
    {
        passengers = p;
        return true;
    }
}
