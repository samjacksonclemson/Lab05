//NICK BUNGE

#include <iostream>
#include <vector>
#include "Student.h"
         
    
        bool Student::setFirstName(string name)
        {
            firstName = name;
            return true;
          
        }
        bool Student::setLastName(string name)
        {
            lastName = name;
            return true;
            
        }
        bool Student::setEmail(string mail)
        {
        bool flagAddressChar = false;
        bool flagPeriodChar = false;
        string input = mail;

           for (int i: input)
           {
             
               if (i == '@')
               {
                   flagAddressChar = true;
               }
               if (i == '.' && flagAddressChar == true)
               {
                   flagPeriodChar = true;
               }
           }
           
           if (flagAddressChar == true && flagPeriodChar == true)
           {
               email = mail;
               return true;
           } else
           {
               return false;
           }


        }
        bool Student::setGradeLevel(string grade){
            string s = "Hello World!";
            int length = grade.length();
            for (int i = 0; i < length; ++i)
            {
                grade[i] = tolower(grade[i]);
            }
            
            if (grade == "freshman" || grade == "sophmore" || grade == "junior" || grade == "senior")
            {
                gradeLevel = grade;
                return true;
            } else
            {return false;}
         
        }
        bool Student::setLivingOnCampus(string onCampus)
        {
          
           if (onCampus == "Y" || onCampus == "y" || onCampus == "yes" || onCampus == "Yes")
            {
                livingOnCampus = true;
                return  true;
            } else if (onCampus == "n" || onCampus == "N" || onCampus == "no" || onCampus == "N")
            {
                livingOnCampus = false;
                return true;
            } else
            {
                return false;
            }
        }
        bool Student::setGPA(double gradePoint)
        {
            gpa = gradePoint;
            return true;
        }
        bool Student::setCuID(string id)
        {
            if ((id[0] != 'C' && id[0] != 'c') || id.length() > 10 || id.length() < 8)
            {
                return false;
            } else
            {
                  cuID = id;
                  return true;
            }
          
        }
        bool Student::setHomeAddress(homeAddress add)
        {
            address = add;
            return true;
        }


        string Student::getFirstName()
        {
            return firstName;
        }
        string Student::getLastName()
        {
            return lastName;
        }
        string Student::getEmail()
        {
            return email;
        }
        string Student::getGradeLevel()
        {
            return gradeLevel;
        }  
        bool Student::getLivingOnCampus()
        {
           return livingOnCampus;
        }
        double Student::getGPA()
        {
            return gpa;
        }
        string Student::getCuID()
        {
            return cuID;
        }
        homeAddress Student::getHomeAddress()
        {
            return address;
        }


        string Student::showHomeAddress()
        {
            string add;
            add = address.houseNumber + " ";
            add += address.street + " ";
            add += address.city + " ";
            add += address.state + " ";
            add += address.zipCode;
            return add;
        }