//Nick Bunge - Student, Motorcycle, Invoice
//Sam Jackson - Employee, Car
//Jonathan Breen - Visitor, Moped
//Riley Westerman - Vendor, Low Emission Vehicle



#include <iostream>
#include <string>
#include <iomanip>
#include <cctype>

using namespace std;

#include "Motorcycle.h"
#include "Student.h"
#include "Employee.h"
#include "Car.h"
#include "Vendor.h"
#include "LowE.h"
#include "Invoice.h"
#include "Visitor.h"
#include "Moped.h"



int main()
{
Invoice invoice;
int personChoice;



cout << "\nPlease enter the # corressponding to your status: " << endl;
cout << "1 - Student" << endl;
cout << "2 - Employee" << endl;
cout << "3 - Visitor" << endl;
cout << "4 - Vendor" << endl;
cout << "\nEnter memu choice: ";
cin >> personChoice;


while(personChoice < 1 || personChoice > 4)
{
    cout << "\nInvalid choice. \nPlease select the number 1-4 corresponding to your status: " << endl;
    cout << "1 - Student\n2 - Employee\n3 - Visitor\n4 - Vendor" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
}



if (personChoice == 1)     //STUDENT ---NICK BUNGE
{
    Student student;
    string userInput;
    homeAddress add;
    bool flag = false;


    cout << "Please enter your first name: ";
    cin >> userInput;
    student.setFirstName(userInput);



    cout << "Please enter your last name: ";
    cin >> userInput;
    student.setLastName(userInput);



    cout << "Enter your email address: ";
    cin >> userInput;
    student.setEmail(userInput);

    //Email validation
    while (!student.setEmail(userInput))
    {
        cout << "Invalid Input.\nPlease enter your email address \"___@____.___\": ";
        cin >> userInput;
        student.setEmail(userInput);
    }

    cout << "Are you living on Campus? Enter \"y\" or \"n\": ";
    cin >> userInput;
    student.setLivingOnCampus(userInput);
    
    //Yes or No validation
    while (!student.setLivingOnCampus(userInput))
    {
        cout <<"Invalid input.\nAre you living on Campus? Enter \"y\" or \"n\": ";
        cin >> userInput;
        student.setLivingOnCampus(userInput);
    }



    cout << "Enter street address (Ex: 1000 Oak St.): ";
    cin.ignore();
    getline(cin, userInput);

    string num;
    string street;
    bool streetFlag = false;
    int strLength;

    for (int i : userInput) //function that parses the house number from the street address
    {
        if (isdigit(i))
        {
           streetFlag = false;
            num += i;
        } else if (isalpha(i) || streetFlag)
        {
            streetFlag = true;
            street += i;
        }
    }
    
    add.street = street;
    add.houseNumber = num;


    cout << "City: ";
    getline(cin, userInput);
    add.city = userInput;

    cout << "State: ";
    getline(cin, userInput);
    add.state = userInput;

    cout << "Zipcode: ";
    cin >> userInput;
    //makes sure zipcode is not longer or shorter than 5 digits
    while (userInput.length() != 5) 
    {
        cout << "Invalid zipcode. Please enter your zipcode again: ";
        cin >> userInput;
    }
    add.zipCode = userInput;
    student.setHomeAddress(add);



    cout << "Please enter your grade level (freshman, sophmore, junior or senior): ";
    cin >> userInput;
    student.setGradeLevel(userInput);
    
    //grade level input validation
    while (!student.setGradeLevel(userInput))
    {
        cout << "Invalid input. Please enter your grade level (freshman, sophmore, junior or senior): ";
        cin >> userInput;
        student.setGradeLevel(userInput);
    }

    cout << "Please enter your GPA: ";
    cin >> userInput;
    flag = false;
    strLength = userInput.length();
     //Tests if GPA was inputed as a double, so in the case a user enters a string it doesn't crash the program
    while (!flag)  
    {
        for (int i = 0; i < strLength; ++i)
        {
            if ((isdigit(userInput[i]) || userInput[i] == '.')&& stod(userInput) <= 4.0 && stod(userInput) >= 0.0 )
            {
                flag = true;
            } else 
            {
                cout << "Invalid input. Please enter your GPA: ";
                cin >> userInput;
                flag = false;
            }      
        }
        if (flag)
        {
            student.setGPA(stod(userInput));
        }
    }
   
    cout << "Please enter your CuId (C########): ";
    cin >> userInput;
    student.setCuID(userInput);
    
    //CUID input validation
    while (!student.setCuID(userInput))
    {
        cout << "Invalid CuID. Please enter your id. Starting with \'C\' followed by 7-10 characters (Ex: C1234567): ";
        cin >> userInput;
        student.setCuID(userInput);
    }

    //inputs Students data into student member variable in invoice class
    invoice.calcStudent(student);
    

} 
else if (personChoice == 2)   //EMPLOYEE -- SAM JACKSON
{
    Employee employee;		// Employee class object
    Address address;		// Address struct object
    string firstName;		// first Name
    string lastName;		// last Name
    string email;			// Email address
    int employeeID;			// employeeID number
    int yearsWorked;		// years worked at Clemson


    cout << "Employee First Name: ";
    cin.ignore();
    getline(cin, firstName);
    employee.setFirstName(firstName);

    cout << "Employee Last Name: ";
    getline(cin, lastName);
    employee.setLastName(lastName);

    cout << "Please enter Home Address info: \n";
    cout << "House Number: ";
    getline(cin, address.houseNumber);
    
    cout << "Street Name: ";
    getline(cin, address.street);

    cout << "City: ";
    getline(cin, address.city);

    cout << "State: ";
    getline(cin, address.state);

    cout << "Zip Code: ";
    getline(cin, address.zipCode);

    employee.setHomeAddress(address);

    cout << "Email: ";
    cin >> email;
    employee.setEmail(email);

    cout << "Employee ID #: ";
    cin >> employeeID;
    employee.setEmployeeID(employeeID);

    cout << "How many years have you worked for Clemson?: ";
    cin >> yearsWorked;
    employee.setYearsWorked(yearsWorked);

    invoice.calcEmployee(employee);
}
 else if (personChoice == 3)   //VISITOR -- JONATHAN BREEN
{
     string userInput;
		int input;
		char alumni;
        Visitor visitor;

        cout << "What's your full name? (First, Last) ";
        cin.ignore();
        getline(cin, userInput);
        visitor.setName(userInput);

		cout << "What's your address? ";
		getline(cin, userInput);
		visitor.setAddress(userInput);

		cout << "What's your email? ";
		getline(cin, userInput);
		visitor.setEmail(userInput);

		cout << "For how many days are you going to stay? ";
		cin >> input;
		while (visitor.setStayLength(input) == false)
		{
			cout << "Please enter a number greater than 0: ";
			cin >> input;
		}

		cout << "Are you an Alumni (Y/N)? ";
		cin >> alumni;
		visitor.setAlumni(alumni);

		invoice.calcVisitor(visitor);

} else if (personChoice == 4)   //VENDOR --RILEY WESTERMAN
{
// For Vendor 4
    Vendor vendor;
    string input;

    cout << "Please enter your first name: ";
	cin >> input;
	vendor.setFirstName(input);

	cout << "Please enter your last name: ";
	cin >> input;
	vendor.setLastName(input);

    cout << "Please enter your street address: ";
    cin.ignore();
    getline(cin, input);
    vendor.setAddress(input);

	cout << "Enter your email address: ";
	cin >> input;
	vendor.setEmail(input);

    cout << "What type of vendor are you: ";
    cin >> input;
    vendor.setVendorType(input);

    cout << "Are you an alumni (y/n): ";
    cin >> input;
    vendor.setAlumni(input);

    while (vendor.setAlumni(input) == false) 
    {
      cout << "Invalid Input, Enter y or n";
      cin >> input;
      vendor.setAlumni(input);
    }

    invoice.calcVendor(vendor);
}



cout << "\nPlease enter the # corressponding to your vehicle: " << endl;
cout << "1 - Car" << endl;
cout << "2 - Low Emission Vehicle" << endl;
cout << "3 - Motorcylce" << endl;
cout << "4 - Moped" << endl;
cout << "\nEnter memu choice: ";
cin >> personChoice;

while(personChoice < 1 || personChoice > 4)
{
    cout << "\nInvalid choice. \nPlease select the number 1-4 corresponding to your status: " << endl;
    cout << "1 - Car\n2 - Low Emission Vehicle\n3 - Motorcycle\n4 - Moped" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
}

if (personChoice == 1)  //CAR -- SAM JACKSON
{
    Car car1;
    int year;
    int days = 1;
    string make;
    string model;
    string color;
    string license;
    string compact;

    cout << "Year of Car (1901 - 2022): ";
    cin >> year;
    while (!car1.setYear(year))
    {
        cout << "Year of Car (1901 - 2022): ";
        cin >> year;
    }
    
    cout << "Make of car: ";
    cin >> make;
    car1.setMake(make);

    cout << "Model of car: ";
    cin >> model;
    car1.setModel(model);

    cout << "Color of car: ";
    cin >> color;
    car1.setColor(color);

    cout << "License Plate #: ";
    cin >> license; 
    car1.setLicensePlate(license);

    cout << "Is car compact? (yes or no): ";
    cin >> compact;
    car1.setIsCompact(compact);

    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Annual" << endl;
    cout << "2 - Semester" << endl;
    cout << "3 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> personChoice;

    while(personChoice < 1 || personChoice > 3)
    {
    cout << "\nInvalid choice. \nPlease enter the 1-3 corressponding to the permit you want:  " << endl;
    cout << "1 - Annual\n2 - Semester\n3 - Daily" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
    }
    
     if (personChoice == 3)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
            cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
            cin >> days;
        }
    } else
    {days = 1;}

    invoice.calcCar(car1,personChoice,days);
} 

else if (personChoice == 2)   //LOW EMISSION VEHICLE -- RILEY WESTERMAN
{
    Low low;
    string input;
    int year;
    int choice;
    int days;

    cout << "Please enter the make of your vehicle: ";
    cin >> input;
    low.setMake(input);

    cout << "Please enter the model of your vehicle: ";
    cin >> input;
    low.setModel(input);

    cout << "Please enter the year you vehicle was made: ";
    cin >> year;
    low.setYearMade(year);

    cout << "Enter your type of low emission car: ";
    cin >> input;
    low.setEmissionType(input);

    while (low.setEmissionType(input) == false) {
    cout << "Invalid Input, Enter Hybrid or Electric";
    cin >> input;
    low.setEmissionType(input);
}

    cout << "What type of vendor are you: ";
    cin >> input;
    low.setLicensePlate(input);

    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Annual" << endl;
    cout << "2 - Semester" << endl;
    cout << "3 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> choice;

    while(choice < 1 || choice > 3)
    {
        cout << "\nInvalid choice. \nPlease enter the 1-3 corressponding to the permit you want:  " << endl;
        cout << "1 - Annual\n2 - Semester\n3 - Daily" << endl;
        cout << "\nEnter menu choice: ";
        cin >> choice;
    }
    
     if (choice == 3)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
            cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
            cin >> days;
        }
    } else
    {days = 1;}



    invoice.calcLowE(low, choice, days);


} else if (personChoice == 3)   //MOTORCYCLE -- NICK BUNGE

{
    Motorcycle motor;
    string userInput;
    int days;
    bool flag = false;
    int strLength;

    cout << "Please enter the make of your motorcycle: ";
    cin.ignore();
    getline(cin, userInput);
    motor.setMake(userInput);
    
    cout << "Please enter the model of your motorcycle: ";
    getline(cin, userInput);
    motor.setModel(userInput);

    cout << "Please enter the year of your motorcycle: ";
    cin >> userInput;
    flag = false;
    strLength = userInput.length();
    //Input validation for year so it a string was entered then it wouldn't crash the program
    while (!flag) 
    {
        for (int i = 0; i < strLength; ++i)
        {
            if (isdigit(userInput[i]) &&  stoi(userInput) >= 1900)
            {
                flag = true;
            } else {
                cout << "Invalid year. Enter the year of your motorcycle: ";
                    cin >> userInput;
                    flag = false;
                }
        }
            if (flag)
            {
            motor.setYear(stoi(userInput));
            }
    }
 
    cout << "Please enter the license plate of your motorcycle: ";
    cin.ignore();
    getline(cin, userInput);
    motor.setLicensePlate(userInput);

    cout << "Please enter the color of your motorcycle: ";
    cin >> userInput;
    motor.setColor(userInput);

    cout << "Does your motorcycle has three wheels? \"y\" or \"n\": ";
    cin >> userInput;
    motor.setHasThreeWheels(userInput);

    //Yes or No validation
    while (!motor.setHasThreeWheels(userInput))
    {
        cout << "Invalid input. Does your motorcycle has three wheels? \"y\" or \"n\": ";
        cin >> userInput;
        motor.setHasThreeWheels(userInput);
    }

    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Semester" << endl;
    cout << "2 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> personChoice;

    //Choice validation
    while(personChoice < 1 || personChoice > 2)
    {
    cout << "\nInvalid choice. \nPlease enter the 1-2 corressponding to the permit you want:  " << endl;
    cout << "1 - Semester\n2 - Daily" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
    }

    if (personChoice == 2)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
        cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        }
    } else
    {days = 1;}

    //Inputs motorcycle data into invoice function
    invoice.calcMotorcycle(motor, personChoice, days);

}


else if (personChoice == 4)    //MOPED -- JONATHAN BREEN
{
    Moped moped;
	string userInput;
	int input, personChoice, days;

		cout << "What is the make of your moped? ";
		cin.ignore();
		getline(cin, userInput);
		moped.setMake(userInput);
		

		cout << "What is the model of your moped? ";
		getline(cin, userInput);
		moped.setModel(userInput);
		

		cout << "What is your License Plate? ";
		getline(cin, userInput);
		moped.setLicensePlate(userInput);
		

		cout << "What is the color of your moped? ";
		getline(cin, userInput);
		moped.setColor(userInput);
		

		cout << "What year is your moped? ";
		cin >> input;
		while (moped.setYear(input) == false)
		{
			cout << "Year must be greater than 0 and less than 2022: ";
			cin >> input;
		}
		

		cout << "How many Passengers will you have? ";
		cin >> input;
		while (moped.setPassengers(input) == false)
		{
			cout << "Passengers must be 0, 1, 2, or 3: ";
			cin >> input;
		}
		
    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Semester" << endl;
    cout << "2 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> personChoice;

    while(personChoice < 1 || personChoice > 2)
    {
    cout << "\nInvalid choice. \nPlease enter the 1-2 corressponding to the permit you want:  " << endl;
    cout << "1 - Semester\n2 - Daily" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
    }
    
     if (personChoice == 2)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
        cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        }
    } else
    {days = 1;}

    invoice.calcMoped(moped, personChoice, days);
}


//Prints out the data and price of the permit
cout << "\n" + invoice.printInvoice() << endl;  //prints the users data and their vehicle info
cout << "\n" + invoice.printPermitCost() << endl;   //prints out the price of the permit and charges/discounts
cout << fixed << setprecision(2) << "Total Price of permit: $" << invoice.getTotalCharge() << endl << endl; //prints out the final cost of the permit 
    
    return 0;
}