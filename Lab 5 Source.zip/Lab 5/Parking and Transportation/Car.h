// Car class specification file
// SAM JACKSON

#ifndef CAR_H_
#define CAR_H_

#include <string>

class Car
{
	private:
		int year {0};
		string make {""};
		string model {""};
		string color {""};
		string licensePlate {""};
		bool isCompact {true};
	public:
		bool setYear(int);
		bool setMake(string);
		bool setModel(string);
		bool setColor(string);
		bool setLicensePlate(string);
		bool setIsCompact(string);

		int getYear();
		string getMake();
		string getModel();
		string getColor();
		string getLicensePlate();
		bool getIsCompact();
};

#endif 		// CAR_H_