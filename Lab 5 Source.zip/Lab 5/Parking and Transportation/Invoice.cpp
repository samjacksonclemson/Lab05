//NICK BUNGE
#include "Invoice.h"
#include <iostream>
#include <math.h>

using namespace std;


void Invoice::calcStudent(Student stud) //Nick Bunge
{
    infoReceipt += "Name: " + stud.getFirstName() + " " + stud.getLastName() + "\n";
    infoReceipt += "Email: " + stud.getEmail() + "\n";
    infoReceipt += "Address: " + stud.showHomeAddress() + "\n";
    infoReceipt += "Grade level: " + stud.getGradeLevel() + "\n";
    
    if (stud.getLivingOnCampus())
    {
        infoReceipt += "Housing status: Living on campus\n";
    } else
    {
        infoReceipt += "Housing status: Living off campus\n";
    }

    int intGpa = stud.getGPA() * 10;
//Formats the double GPA into a string for the receipt with one decimal place
    if (intGpa % 10 == 0)
    {
        infoReceipt += "GPA: " + to_string((intGpa - (intGpa % 10))/10) + ".0\n";
    } else 
    {
        infoReceipt += "GPA: " + to_string((intGpa - (intGpa % 10))/10) + "." + to_string(intGpa % 10) + "\n";
    }

    infoReceipt += "CuID: " + stud.getCuID() + "\n\n";

    invoiceStud = stud;
    classesUsed[0] = true;
}

void Invoice::calcMotorcycle(Motorcycle motor, int permitType, int days)  //Nick Bunge
{
    infoReceipt += "Make: " + motor.getMake() + "\n";
    infoReceipt += "Model: " + motor.getModel() + "\n";
    infoReceipt += "Year: " + to_string(motor.getYear()) + "\n";
    infoReceipt += "License Plate: " + motor.getLicensePlate() + "\n";
    infoReceipt += "Color: " + motor.getColor() + "\n";
    
    if (motor.getHasThreeWheels())
    {
        infoReceipt += "Type: Trike (3 wheels)\n";
    } else
    { infoReceipt += "Type: Motorcycle (2 wheels)\n";}
    
    invoiceMotor = motor;
    permit = permitType + 1; //to accounbt for that motorcylces dont have annual permit
    if (permitType == 2)
    {numDays = days;}
    classesUsed[6] = true;
}

void Invoice::calcEmployee(Employee e) // SAM JACKSON
{

	infoReceipt += "Name: " + e.getFirstName() + " " + e.getLastName() + "\n";
    infoReceipt += "Email: " + e.getEmail() + "\n";
    infoReceipt += "Address: " + e.getHomeAddress() + "\n";
    infoReceipt += "Employee ID: " + to_string(e.getEmployeeID()) + "\n";

	// test for long-term discount
	if (e.getYearsWorked() >= 5)
	{
		infoReceipt += "Qualify for Long-Term Employee Discount: Yes\n";
	}
		
	else
	{
		infoReceipt += "Qualify for Long-Term Employee Discount: No\n";
	}

	// copy object e into invoiceEmp
	invoiceEmployee = e;

	// indicate Employee class is used
	classesUsed[1] = true;
    infoReceipt += "\n";
}

void Invoice::calcCar(Car c, int permitType, int days) // SAM JACKSON
{
	infoReceipt += "Make: " + c.getMake() + "\n";
    infoReceipt += "Model: " + c.getModel() + "\n";
    infoReceipt += "Year: " + to_string(c.getYear()) + "\n";
    infoReceipt += "License Plate: " + c.getLicensePlate() + "\n";
    infoReceipt += "Color: " + c.getColor() + "\n";

	if (c.getIsCompact())
	{
		infoReceipt += "Compact: Yes\n";
	}
	else 
	{
		infoReceipt += "Compact: No\n";
	}

    permit = permitType;
	// copy object c into invoiceCar
	invoiceCar = c;

	// indicate Car class is used
	classesUsed[4] = true;
}



string Invoice::printPermitCost() //Nick Bunge
{

int intCharge;


switch (permit)
{
case 1:
    totalCharge = 120.00; 
    chargeReceipt += "\nPrice of Annual Permit: $120.00\n";
    break;
case 2:
    totalCharge = 70.00;
    chargeReceipt += "\nPrice of Semester Permit: $70.00\n";
    break;
case 3:
    totalCharge = 7.00 * numDays;
    intCharge = totalCharge * 100;
   //Formats the double intCharge into a string for the receipt with two decimal places
    if (intCharge % 100 == 0)
        {
            chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
            if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Price of Daily permit: $" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
break;
}
       
        intCharge = totalCharge * 0.05 * 100;
        totalCharge = totalCharge + (totalCharge * .05);
         //Formats the double intCharge into a string for the receipt with two decimal places
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Processing fee: +$" + to_string(((intCharge - (intCharge % 100))/100)) + ".00\n";
        } else
        {
            if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Processing fee: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Processing fee: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }

if (classesUsed[0]) //Student
{ 
    if (invoiceStud.getGPA() >= 3.0)    //discount if student has high gpa
    {

        
         intCharge = totalCharge * 0.1 * 100;
          totalCharge = totalCharge - (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "High GPA discount: -$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
        
    
    }
} else if (classesUsed[1]) //Employee
{
    if (invoiceEmployee.getYearsWorked() >= 5)
    {
         intCharge = totalCharge * 0.1 * 100;
          totalCharge = totalCharge - (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Employee 5 years or more discount: -$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
    }
} else if (classesUsed[2]) //Visitor
{

} else if (classesUsed[3]) //Vendor
{

}


if (classesUsed[4]) //Car 
{
    if (!invoiceCar.getIsCompact())
    {
        intCharge = totalCharge * 0.1 * 100;
        totalCharge = totalCharge + (totalCharge * 0.1);
        //intCharge is used to set the precision to 2 since I can't do setprecision(2) cause there is no cout function
        if (intCharge % 100 == 0)
        {
            chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
             if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Non-compact car charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
        }
    }
} else if (classesUsed[5]) //Low Emission Vehicle
 {

} else if (classesUsed[6]) //Motorcylce
{
    if (invoiceMotor.getHasThreeWheels()) //25% charge if it is a trike
    {   

        intCharge = totalCharge * .25 * 100;
        totalCharge = totalCharge + (totalCharge * .25);
         if (intCharge % 100 == 0)
        {
            chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".00\n";
        } else
        {
           if (intCharge % 100 <= 9)
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + ".0" + to_string(intCharge % 100) + "\n";
           } else
           {
               chargeReceipt += "Trike charge: +$" + to_string((intCharge - (intCharge % 100))/100) + "." + to_string(intCharge % 100) + "\n";
           }
            
        }
        
    }
} else if (classesUsed[7]) //Moped
{

}
    return chargeReceipt;
}

double Invoice::getTotalCharge()
{
    return totalCharge;
}

string Invoice::printInvoice()
{
    return infoReceipt;
}