// Riley Westerman

#include "LowE.h"

#include <iomanip>
#include <iostream>
#include <string>

using namespace std;

void Low::setMake(string m) { // Setter function
  make = m;
}

void Low::setModel(string mo) {
  model = mo;
}

bool Low::setYearMade(int y) {
  if ((y >= 1900) || (y <= 2022)) {
    yearMade = y;
    return true;
  }
  else {
    yearMade = yearMade;
    return false;
  }
}

bool Low::setEmissionType(string e) {
  if ((e == "Hybrid") || (e == "hybrid") || (e == "Electric") || (e == "electric")) {
    emissionType = e;
    return true;
  }
  else {
    return false;
  }
}

void Low::setLicensePlate(string l) {
  licensePlate = l;
}


string Low::getMake() { // Getter function
  return make;
}
string Low::getModel() {
  return model;
}
int Low::getYearMade() {
  return yearMade;
}
string Low::getEmissionType() {
  return emissionType;
}
string Low::getLicensePlate() {
  return licensePlate;
}