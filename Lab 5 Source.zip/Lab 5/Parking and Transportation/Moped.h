// Moped class definition

#ifndef MOPED_H_
#define MOPED_H_

#include <string>
using namespace std;

class Moped
{
    private:
        string make {""};
        string model {""};
        string licensePlate {""};
        string color {""};
        int year {0};
        int passengers {0};
    public:
        Moped() = default;

        void setMake(string mk);
        void setModel(string ml);
        void setLicensePlate(string l);
        void setColor(string c);
        bool setYear(int y);
        bool setPassengers(int p);

        string getMake()
        {return make;}
        string getModel()
        {return model;}
        string getLicensePlate()
        {return licensePlate;}
        string getColor()
        {return color;}
        int getYear()
        {return year;}
        int getPassengers()
        {return passengers;}
};

#endif// Moped class definition

#ifndef MOPED_H_
#define MOPED_H_

#include <string>
using namespace std;

class Moped
{
    private:
        string make {""};
        string model {""};
        string licensePlate {""};
        string color {""};
        int year {0};
        int passengers {0};
    public:
        Moped() = default;

        void setMake(string mk);
        void setModel(string ml);
        void setLicensePlate(string l);
        void setColor(string c);
        bool setYear(int y);
        bool setPassengers(int p);

        string getMake()
        {return make;}
        string getModel()
        {return model;}
        string getLicensePlate()
        {return licensePlate;}
        string getColor()
        {return color;}
        int getYear()
        {return year;}
        int getPassengers()
        {return passengers;}
};

#endif