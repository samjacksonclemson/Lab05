//NICK BUNGE

#include <iostream>
#include <string>
#include "Motorcycle.h"

using namespace std;



 bool Motorcycle::setMake(string m)
 {
     make = m;
     return true;
 }
bool Motorcycle::setModel(string m)
{
    model = m;
    return true;
}
bool Motorcycle::setYear(int y)
{
    if (y >= 1900)
    {
        year = y;
        return true;
    } else
    {return false;}

}
bool Motorcycle::setLicensePlate(string plate)
{
    licensePlate = plate;
    return true;
}
bool Motorcycle::setColor(string c)
{
    color = c;
    return true;
}
bool Motorcycle::setHasThreeWheels(string trike)
{
    
    if (trike == "Y" || trike == "y" || trike == "yes" || trike == "Yes")
        {
            hasThreeWheels = true;
            return  true;
        } else if (trike == "n" || trike == "N" || trike == "no" || trike == "N")
        {
            hasThreeWheels = false;
            return true;
        } else
        {
            return false;
        }
}


string Motorcycle::getMake()
{
    return make;
}
string Motorcycle::getModel()
{
    return model;
}
int Motorcycle::getYear()
{
    return year;
}
string Motorcycle::getLicensePlate()
{
    return licensePlate;
}
string Motorcycle::getColor()
{
    return color;
}
bool Motorcycle::getHasThreeWheels()
{
    return hasThreeWheels;
}
        
