//NICK BUNGE

#ifndef MOTORCYCLE_H_
#define MOTORCYCLE_H_
#include <string>

using namespace std;

class Motorcycle
{
    private:
        string make {""};
        string model {""};
        int year {0};
        string licensePlate{""};
        string color {""};
        bool hasThreeWheels {false};


    public:
        Motorcycle() = default;
        bool setMake(string m);
        bool setModel(string m);
        bool setYear(int y);
        bool setLicensePlate(string plate);
        bool setColor(string c);
        bool setHasThreeWheels(string trike);

        string getMake();
        string getModel();
        int getYear();
        string getLicensePlate();
        string getColor();
        bool getHasThreeWheels();
        
};




#endif