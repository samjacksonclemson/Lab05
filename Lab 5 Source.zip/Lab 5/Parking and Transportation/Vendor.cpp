// Riley Westerman

#include "Vendor.h"

#include <iomanip>
#include <iostream>
#include <string>

using namespace std;

void Vendor::setFirstName(string f) { // Setter function
  firstName = f;
}

void Vendor::setLastName(string l) {
  lastName = l;
}

void Vendor::setAddress(string a) {
  address = a;
}

void Vendor::setEmail(string e) {
  email = e;
}

void Vendor::setVendorType(string v) {
  vendorType = v;
}

bool Vendor::setAlumni(char y) {
  if ((y = 'y') || (y = 'Y')) {
    alumni = y;
    return true;
  }
  else if ((y = 'n') || (y = 'N')) {
    alumni = y;
    return true
  }
  else {
    alumni = alumni;
    return false;
  }
}

string Vendor::getFirstName() { // Getter function
  return firstName;
}

string Vendor::getLastName() {
  return lastName;
}

string Vendor::getAddress() {
  return address;
}

string Vendor::getEmail() {
  return email;
}

string Vendor::getVendorType() {
  return vendorType;
}

string Vendor::getAlumni() {
  return alumni;
}