// Riley Westerman

#ifndef VENDOR_H_
#define VENDOR_H_
#include <string>

using namespace std;

class Vendor
{
  private: // Variables
    string firstName {""};
    string lastName {""};
    string address {""};
    string email {""};
    string vendorType {""};
    char alumni();

  public:
    Vendor() = default; // Constructor
    Vendor(string f, string l, string a, string e, string v) : firstName {f}, lastName {l}, address {a}, email {e}, vendorType {v} {}

    void setFirstName(string firstName);
    void setLastName(string lastName);
    void setAddress(string address);
    void setEmail(string email);
    void setVendorType(string vendorType);
    bool setAlumni(bool alumni);

    string getFirstName();
    string getLastName();
    string getAddress();
    string getEmail();
    string getVendorType();
    string getAlumni();
};



#endif
