//Nick Bunge, Sam Jackson, Jonathan Breen, Riley Westerman
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#include "Motorcycle.h"
#include "Student.h"
#include "Employee.h"
#include "Car.h"
#include "Vendor.h"
#include "LowE.h"
#include "Invoice.h"



int main()
{
Invoice invoice;
int personChoice;



cout << "\nPlease enter the # corressponding to your status: " << endl;
cout << "1 - Student" << endl;
cout << "2 - Employee" << endl;
cout << "3 - Visitor" << endl;
cout << "4 - Vendor" << endl;
cout << "\nEnter memu choice: ";
cin >> personChoice;


while(personChoice < 1 || personChoice > 4)
{
    cout << "\nInvalid choice. \nPlease select the number 1-4 corresponding to your status: " << endl;
    cout << "1 - Student\n2 - Employee\n3 - Visitor\n4 - Vendor" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
}



if (personChoice == 1)     //STUDENT ---Nick Bunge
{
    Student student;
    string userInput;
    homeAddress add;
    bool flag = false;


    cout << "Please enter your first name: ";
    cin >> userInput;
    student.setFirstName(userInput);



    cout << "Please enter your last name: ";
    cin >> userInput;
    student.setLastName(userInput);



    cout << "Enter your email address: ";
    cin >> userInput;
    student.setEmail(userInput);

    while (!student.setEmail(userInput))
    {
        cout << "Invalid Input.\nPlease enter your email address \"___@____.___\": ";
        cin >> userInput;
        student.setEmail(userInput);
    }

    cout << "Are you living on Campus? Enter \"y\" or \"n\": ";
    cin >> userInput;
    student.setLivingOnCampus(userInput);
    
    while (!student.setLivingOnCampus(userInput))
    {
        cout <<"Invalid input.\nAre you living on Campus? Enter \"y\" or \"n\": ";
        cin >> userInput;
        student.setLivingOnCampus(userInput);
    }



    cout << "Enter street address (Ex: 1000 Oak St.): ";
    cin.ignore();
    getline(cin, userInput);

    string num;
    string street;
    bool streetFlag = false;
    int strLength;

    for (int i : userInput) //function that parses the house number from the street address
    {
        if (isnumber(i))
        {
           streetFlag = false;
            num += i;
        } else if (isalpha(i) || streetFlag)
        {
            streetFlag = true;
            street += i;
        }
    }
    
    add.street = street;
    add.houseNumber = num;


    cout << "City: ";
    getline(cin, userInput);
    add.city = userInput;

    cout << "State: ";
    getline(cin, userInput);
    add.state = userInput;

    cout << "Zipcode: ";
    cin >> userInput;
 
    while (userInput.length() != 5) //makes sure zipcode is not longer or shorter than 5 digits
    {
        cout << "Invalid zipcode. Please enter your zipcode again: ";
        cin >> userInput;
    }
    add.zipCode = userInput;
    student.setHomeAddress(add);



    cout << "Please enter your grade level (freshman, sophmore, junior or senior): ";
    cin >> userInput;
    student.setGradeLevel(userInput);
    
    while (!student.setGradeLevel(userInput))
    {
        cout << "Invalid input. Please enter your grade level (freshman, sophmore, junior or senior): ";
        cin >> userInput;
        student.setGradeLevel(userInput);
    }


    
    cout << "Please enter your GPA: ";
    cin >> userInput;
    flag = false;
    strLength = userInput.length();
    while (!flag)   //Tests if GPA was inputed as a double, so in the case a user enters a string it doesn't crash the program
    {
        for (int i = 0; i < strLength; ++i)
        {
            if ((isdigit(userInput[i]) || userInput[i] == '.')&& stod(userInput) <= 4.0 && stod(userInput) >= 0.0 )
            {
                flag = true;
            } else 
            {
                cout << "Invalid input. Please enter your GPA: ";
                cin >> userInput;
                flag = false;
            }      
        }
        if (flag)
        {
            student.setGPA(stod(userInput));
        }
    }
   
    cout << "Please enter your CuId (C########): ";
    cin >> userInput;
    student.setCuID(userInput);
    
    while (!student.setCuID(userInput))
    {
        cout << "Invalid CuID. Please enter your id. Starting with \'C\' followed by 7-10 characters (Ex: C1234567): ";
        cin >> userInput;
        student.setCuID(userInput);
    }

    invoice.calcStudent(student);
    

} 
else if (personChoice == 2)   //EMPLOYEE --
{
    Employee employee;		// Employee class object
    Address address;		// Address struct object
    string firstName;		// first Name
    string lastName;		// last Name
    string email;			// Email address
    int employeeID;			// employeeID number
    int yearsWorked;		// years worked at Clemson


    cout << "Employee First Name: ";
    cin.ignore();
    getline(cin, firstName);
    employee.setFirstName(firstName);

    cout << "Employee Last Name: ";
    getline(cin, lastName);
    employee.setLastName(lastName);

    cout << "Please enter Home Address info: \n";
    cout << "House Number: ";
    getline(cin, address.houseNumber);
    
    cout << "Street Name: ";
    getline(cin, address.street);

    cout << "City: ";
    getline(cin, address.city);

    cout << "State: ";
    getline(cin, address.state);

    cout << "Zip Code: ";
    getline(cin, address.zipCode);

    employee.setHomeAddress(address);

    cout << "Email: ";
    cin >> email;
    employee.setEmail(email);

    cout << "Employee ID #: ";
    cin >> employeeID;
    employee.setEmployeeID(employeeID);

    cout << "How many years have you worked for Clemson?: ";
    cin >> yearsWorked;
    employee.setYearsWorked(yearsWorked);

    invoice.calcEmployee(employee);
}
 else if (personChoice == 3)   //VISITOR --
{

} else if (personChoice == 4)   //VENDOR --RILEY
{

}



cout << "\nPlease enter the # corressponding to your vehicle: " << endl;
cout << "1 - Car" << endl;
cout << "2 - Low Emission Vehicle" << endl;
cout << "3 - Motorcylce" << endl;
cout << "4 - Moped" << endl;
cout << "\nEnter memu choice: ";
cin >> personChoice;

while(personChoice < 1 || personChoice > 4)
{
    cout << "\nInvalid choice. \nPlease select the number 1-4 corresponding to your status: " << endl;
    cout << "1 - Car\n2 - Low Emission Vehicle\n3 - Motorcycle\n4 - Moped" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
}

if (personChoice == 1)  //CAR
{
    Car car1;
    int year;
    int days = 1;
    string make;
    string model;
    string color;
    string license;
    string compact;

    cout << "Year of Car (1901 - 2022): ";
    cin >> year;
    while (!car1.setYear(year))
    {
        cout << "Year of Car (1901 - 2022): ";
        cin >> year;
    }
    
    cout << "Make of car: ";
    cin >> make;
    car1.setMake(make);

    cout << "Model of car: ";
    cin >> model;
    car1.setModel(model);

    cout << "Color of car: ";
    cin >> color;
    car1.setColor(color);

    cout << "License Plate #: ";
    cin >> license; 
    car1.setLicensePlate(license);

    cout << "Is car compact? (yes or no): ";
    cin >> compact;
    car1.setIsCompact(compact);

    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Annual" << endl;
    cout << "2 - Semester" << endl;
    cout << "3 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> personChoice;

    while(personChoice < 1 || personChoice > 3)
    {
    cout << "\nInvalid choice. \nPlease enter the 1-3 corressponding to the permit you want:  " << endl;
    cout << "1 - Annual\n2 - Semester\n3 - Daily" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
    }
    
     if (personChoice == 3)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
        cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        }
    } else
    {days = 1;}

    invoice.calcCar(car1,personChoice,days);
} 

else if (personChoice == 2)   //LOW EMISSION VEHICLE --RILEY
{

} else if (personChoice == 3)   //MOTORCYCLE -- NICK BUNGE

{
    Motorcycle motor;
    string userInput;
    int days;
    bool flag = false;
    int strLength;

    cout << "Please enter the make of your motorcycle: ";
    cin.ignore();
    getline(cin, userInput);
    motor.setMake(userInput);
    
    cout << "Please enter the model of your motorcycle: ";
    //cin.ignore();
    getline(cin, userInput);
    motor.setModel(userInput);

    cout << "Please enter the year of your motorcycle: ";
    cin >> userInput;
    flag = false;
    strLength = userInput.length();
    while (!flag) //Tests if GPA was inputed as a double, so in the case a user enters a string it doesn't crash the program
    {
        for (int i = 0; i < strLength; ++i)
        {
            if (isdigit(userInput[i]) &&  stoi(userInput) >= 1900)
            {
                flag = true;
            } else {
                cout << "Invalid year. Enter the year of your motorcycle: ";
                    cin >> userInput;
                    flag = false;
                }
        }
            if (flag)
            {
            motor.setYear(stoi(userInput));
            }
    }
 
    cout << "Please enter the license plate of your motorcycle: ";
    cin.ignore();
    getline(cin, userInput);
    motor.setLicensePlate(userInput);

    cout << "Please enter the color of your motorcycle: ";
    cin >> userInput;
    motor.setColor(userInput);

    cout << "Does your motorcycle has three wheels? \"y\" or \"n\": ";
    cin >> userInput;
    motor.setHasThreeWheels(userInput);

    while (!motor.setHasThreeWheels(userInput))
    {
        cout << "Invalid input. Does your motorcycle has three wheels? \"y\" or \"n\": ";
        cin >> userInput;
        motor.setHasThreeWheels(userInput);
    }

    cout << "\nPlease enter the # corressponding to the permit you want: " << endl;
    cout << "1 - Semester" << endl;
    cout << "2 - Daily" << endl;
    cout << "\nEnter memu choice: ";
    cin >> personChoice;

    while(personChoice < 1 || personChoice > 2)
    {
    cout << "\nInvalid choice. \nPlease enter the 1-2 corressponding to the permit you want:  " << endl;
    cout << "1 - Semester\n2 - Daily" << endl;
    cout << "\nEnter menu choice: ";
    cin >> personChoice;
    }

    if (personChoice == 2)
    {
        cout << "Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        
        while (days <= 0)
        {
        cout << "Invalid input. Please enter the amount of days you will need for the daily pass: ";
        cin >> days;
        }
    } else
    {days = 1;}

    invoice.calcMotorcycle(motor, personChoice, days);

}


else if (personChoice == 4)    //MOPED
{

}


//Prints out the data and price of the permit
cout << "\n" + invoice.printInvoice() << endl;
cout << "\n" + invoice.printPermitCost() << endl;
cout << fixed << setprecision(2) << "Total Price of permit: $" << invoice.getTotalCharge() << endl << endl;
    
    return 0;
}