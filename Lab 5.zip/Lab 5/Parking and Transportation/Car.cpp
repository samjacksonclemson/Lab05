// function implementation file for Car class
// SAM JACKSON

#include <string>

using namespace std;

#include "Car.h"

// setter functions:

bool Car::setYear(int y)
{
		year = y;
		return true;
}

bool Car::setMake(string mk)
{
	make = mk;
	return true;
}

bool Car::setModel(string mdl) 
{
	model = mdl;
	return true;
}

bool Car::setColor(string c)
{
	color = c;
	return true;
}

bool Car::setLicensePlate(string lp)
{
	licensePlate = lp;
	return true;
}

bool Car::setIsCompact(string compact)
{
	if (compact == "yes" || compact == "Yes")
	{
		isCompact = true;
		return true;
	}
	
	else 
		return false;
}

// Getter functions:

int Car::getYear()
{ return year; }

string Car::getMake()
{ return make; }

string Car::getModel()
{ return model; }

string Car::getColor()
{ return color; }

string Car::getLicensePlate()
{ return licensePlate; }

bool Car::getIsCompact()
{ return isCompact; }