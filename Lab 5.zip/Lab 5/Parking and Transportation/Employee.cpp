// function implementation file for Employee class

#include <string>

using namespace std;

#include "Employee.h"

// setter functions

bool Employee::setFirstName(string fn)
{
	firstName = fn;
	return true;
}

bool Employee::setLastName(string ln)
{
	lastName = ln;
	return true;
}

bool Employee::setHomeAddress(Address ha)
{
	homeAddress = ha.houseNumber + " " + ha.street + " " 
		+ ha.city + " " + ha.state + " " + ha.zipCode;
	return true;
}

bool Employee::setEmail(string em)
{
	email = em;
	return true;
}

bool Employee::setEmployeeID(int eID)
{
	employeeID = eID;
	return true;
}

bool Employee::setYearsWorked(int yw)
{
	yearsWorked = yw;
	return true;
}

// getter functions

string Employee::getFirstName()
{ return firstName; }

string Employee::getLastName()
{ return lastName; }

string Employee::getHomeAddress()
{ return homeAddress; }

string Employee::getEmail()
{ return email; }

int Employee::getEmployeeID()
{ return employeeID; }

int Employee::getYearsWorked()
{ return yearsWorked; }



