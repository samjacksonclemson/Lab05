//NICK BUNGE

#ifndef INVOICE_H_
#define INVOICE_H_
#include "Student.h"
#include "Motorcycle.h"
#include "Car.h"
#include "Employee.h"


class Invoice 
{
private:
    bool classesUsed[8] {false, false, false, false, false,false,false,false};
    /* 
    Index
    0       Student
    1       Employee
    2       Visitor
    3       Vendor
    4       Car
    5       Low Emission Vehicle
    6       Motorcycle
    7       Moped
    */
   int permit;
   /*  
    1 = Annual Permit
    2 = Semester 
    3 = Daily
   */
    int numDays;
    double totalCharge {0.00};
    string  infoReceipt {""};
    string chargeReceipt {""};
    Student invoiceStud;
    Motorcycle invoiceMotor;
    Car invoiceCar;
    Employee invoiceEmployee;

public:
    Invoice() = default;
    void calcStudent(Student);
    void calcMotorcycle(Motorcycle, int, int);
    void calcEmployee(Employee);
    void calcCar(Car, int, int);
    // double calcVisitor(Visitor);
    string printInvoice();
    string printPermitCost();
    double getTotalCharge();
};

#endif