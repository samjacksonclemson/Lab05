// Riley Westerman

#ifndef LOW_E_H_
#define LOW_E_H_
#include <string>
using namespace std;

class Low
{
  private: // Variables
    string make {""};
    string model {""};
    string yearMade {""};
    string emissionType {""};
    string licensePlate {""};

  public:
    Low() = default; // Constructor
    Low(string m, string mo, string y, string e, string l) : make {m}, model {mo}, yearMade {y}, emissionType {e}, licensePlate {l} {}

    void setMake(string make);
    void setModel(string model);
    bool setYearMade(string yearMade);
    bool setEmissionType(string emissionType);
    void setLicensePlate(string licensePlate);

    string getMake();
    string getModel();
    string getYearMade();
    string getEmissionType();
    string getLicensePlate();
};

#endif