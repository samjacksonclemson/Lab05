//NICK BUNGE

#ifndef STUDENT_H_
#define STUDENT_H_

#include <string>
using namespace std;

 struct homeAddress
        {
            string houseNumber;
            string street;
            string city;
            string state;
            string zipCode;
        };

class Student
{
    private:
        string firstName {""};
        string lastName {""};
        string email {""};
        string gradeLevel {"freshman"};
        bool livingOnCampus {false};
        double gpa {0.0};
        string cuID {""};
        homeAddress address;
      
        
    public:

        bool setFirstName(string name);
        bool setLastName(string name);
        bool setEmail(string mail);
        bool setGradeLevel(string grade);
        bool setLivingOnCampus(string onCampus);
        bool setGPA(double gradePoint);
        bool setCuID(string id);
        bool setHomeAddress(homeAddress add);

        string getFirstName();
        string getLastName();
        string getEmail();
        string getGradeLevel();
        bool getLivingOnCampus();
        double getGPA();
        string getCuID();
        homeAddress getHomeAddress();

        string showHomeAddress();

};



#endif