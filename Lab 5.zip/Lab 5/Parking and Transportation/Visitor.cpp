// Visitor class set function definitions

#include <string>
#include "visitor.h"

using namespace std;

void Visitor::setName(string n)
{
    name = n;
}

void Visitor::setAddress(string a)
{
    address = a;
}

void Visitor::setEmail(string e)
{
    email = e;
}

bool Visitor::setStayLength(int s)
{
    if (s > 0)
    {
        stayLength = s;
        return true;
    }
    else return false;
}

void Visitor::setAlumni(char i)
{
    if (i == 'y' || i == 'Y')
    {
        alumni = true;
    }
    else
    {
        alumni = false;
    }
}
