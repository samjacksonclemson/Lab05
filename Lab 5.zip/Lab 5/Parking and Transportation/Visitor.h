// Visitor class declaration

#ifndef VISITORS_H_
#define VISITORS_H_

#include <string>
using namespace std;

class Visitor
{
    private:
        string name {""};
        string address {""};
        string email {""};
        int stayLength {0};
        bool alumni {false};
    public:
        Visitor() = default;
        
        void setName(string n);
        void setAddress(string a);
        void setEmail(string e);
        bool setStayLength(int s);
        void setAlumni(char i);

        string getName()
        {return name;}
        string getAddress()
        {return address;}
        string getEmail()
        {return email;}
        int getStayLength()
        {return stayLength;}
        bool getAlumni()
        {return alumni;}
};

#endif